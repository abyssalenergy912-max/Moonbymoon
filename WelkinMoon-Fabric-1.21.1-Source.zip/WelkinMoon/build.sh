#!/usr/bin/env sh
set -eu
if ! command -v java >/dev/null 2>&1; then echo "Java 21 is required" >&2; exit 1; fi
if ! command -v gradle >/dev/null 2>&1; then echo "Gradle 8.8+ is required (or use the included GitHub Actions workflow)." >&2; exit 1; fi
gradle build --no-daemon
