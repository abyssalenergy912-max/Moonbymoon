@echo off
where java >nul 2>nul || (echo Java 21 is required & exit /b 1)
where gradle >nul 2>nul || (echo Gradle 8.8+ is required. You can use the included GitHub Actions workflow. & exit /b 1)
gradle build --no-daemon
