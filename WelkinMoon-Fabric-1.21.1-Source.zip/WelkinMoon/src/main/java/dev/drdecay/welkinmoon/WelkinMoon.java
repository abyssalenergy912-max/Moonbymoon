package dev.drdecay.welkinmoon;

import dev.drdecay.welkinmoon.block.MetalStringBlock;
import dev.drdecay.welkinmoon.block.BagOfCementBlock;
import dev.drdecay.welkinmoon.entity.ConstructorZombieEntity;
import dev.drdecay.welkinmoon.entity.GloomStalkerEntity;
import dev.drdecay.welkinmoon.entity.StrongholdBossEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.ConcretePowderBlock;
import net.minecraft.block.IronBarsBlock;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.PillarBlock;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.WallBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.AxeItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.World;
import net.minecraft.entity.mob.ZombieEntity;

import java.util.List;

public final class WelkinMoon implements ModInitializer {
    public static final String MOD_ID = "welkin_moon";
    private static Identifier id(String path) { return Identifier.of(MOD_ID, path); }

    public static final RegistryEntry.Reference<StatusEffect> SOURNESS = Registry.registerReference(
        Registries.STATUS_EFFECT, id("sourness"), new StatusEffect(StatusEffectCategory.HARMFUL, 0xA4B64C) {});

    public record TreeSet(Block log, Block wood, Block strippedLog, Block strippedWood, Block planks, Block leaves) {}

    private static Block registerBlock(String name, Block block) {
        Registry.register(Registries.BLOCK, id(name), block);
        Registry.register(Registries.ITEM, id(name), new BlockItem(block, new Item.Settings()));
        return block;
    }
    private static Item registerItem(String name, Item item) { return Registry.register(Registries.ITEM, id(name), item); }
    private static TreeSet registerTree(String prefix, Block logBase, Block woodBase, Block plankBase, Block leavesBase) {
        Block log = registerBlock(prefix + "_log", new PillarBlock(AbstractBlock.Settings.copy(logBase)));
        Block wood = registerBlock(prefix + "_wood", new PillarBlock(AbstractBlock.Settings.copy(woodBase)));
        Block strippedLog = registerBlock("stripped_" + prefix + "_log", new PillarBlock(AbstractBlock.Settings.copy(logBase)));
        Block strippedWood = registerBlock("stripped_" + prefix + "_wood", new PillarBlock(AbstractBlock.Settings.copy(woodBase)));
        Block planks = registerBlock(prefix + "_planks", new Block(AbstractBlock.Settings.copy(plankBase)));
        Block leaves = registerBlock(prefix + "_leaves", new LeavesBlock(AbstractBlock.Settings.copy(leavesBase)));
        return new TreeSet(log, wood, strippedLog, strippedWood, planks, leaves);
    }
    private static Block variants(String name, Block base) { return registerBlock(name, new Block(AbstractBlock.Settings.copy(base))); }
    private static void registerStoneSet(String prefix, Block base) {
        Block bricks = variants(prefix, base);
        registerBlock(prefix + "_stairs", new StairsBlock(bricks.getDefaultState(), AbstractBlock.Settings.copy(base)));
        registerBlock(prefix + "_slab", new SlabBlock(AbstractBlock.Settings.copy(base)));
        registerBlock(prefix + "_wall", new WallBlock(AbstractBlock.Settings.copy(base)));
    }

    public static final TreeSet BLACKWOOD = registerTree("blackwood", Blocks.OAK_LOG, Blocks.OAK_WOOD, Blocks.OAK_PLANKS, Blocks.OAK_LEAVES);
    public static final TreeSet GLOOMWOOD = registerTree("gloomwood", Blocks.SPRUCE_LOG, Blocks.SPRUCE_WOOD, Blocks.SPRUCE_PLANKS, Blocks.SPRUCE_LEAVES);
    public static final TreeSet MOONWOOD = registerTree("moonwood", Blocks.BIRCH_LOG, Blocks.BIRCH_WOOD, Blocks.BIRCH_PLANKS, Blocks.BIRCH_LEAVES);
    public static final TreeSet CARAMBOLA_TREE = registerTree("carambola", Blocks.JUNGLE_LOG, Blocks.JUNGLE_WOOD, Blocks.JUNGLE_PLANKS, Blocks.JUNGLE_LEAVES);

    public static final Block TIN_ORE = registerBlock("tin_ore", new Block(AbstractBlock.Settings.copy(Blocks.IRON_ORE)));
    public static final Block DEEPSLATE_TIN_ORE = registerBlock("deepslate_tin_ore", new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_IRON_ORE)));
    public static final Item TIN_INGOT = registerItem("tin_ingot", new Item(new Item.Settings()));
    public static final Item TIN_NUGGET = registerItem("tin_nugget", new Item(new Item.Settings()));

    public static final Block CORRUGATED_METAL_WALL = registerBlock("corrugated_metal_wall", new WallBlock(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK)));
    public static final Block BAMBOO_PILLAR = registerBlock("bamboo_pillar", new IronBarsBlock(AbstractBlock.Settings.copy(Blocks.IRON_BARS)));
    public static final Item BAMBOO_STICK = registerItem("bamboo_stick", new Item(new Item.Settings()));
    public static final Block METAL_STRING = registerBlock("metal_string", new MetalStringBlock(AbstractBlock.Settings.copy(Blocks.TRIPWIRE).strength(0.2f).noCollision()));

    public static final Block SOLID_CEMENT = registerBlock("solid_cement", new Block(AbstractBlock.Settings.copy(Blocks.STONE).strength(2.0f, 6.0f)));
    public static final Block SOLID_CEMENT_STAIRS = registerBlock("solid_cement_stairs", new StairsBlock(SOLID_CEMENT.getDefaultState(), AbstractBlock.Settings.copy(SOLID_CEMENT)));
    public static final Block SOLID_CEMENT_SLAB = registerBlock("solid_cement_slab", new SlabBlock(AbstractBlock.Settings.copy(SOLID_CEMENT)));
    public static final Block SOLID_CEMENT_WALL = registerBlock("solid_cement_wall", new WallBlock(AbstractBlock.Settings.copy(SOLID_CEMENT)));
    public static final Block CEMENT_BLOCK = registerBlock("cement_block", new ConcretePowderBlock(SOLID_CEMENT, AbstractBlock.Settings.copy(Blocks.GRAVEL).strength(0.6f)));
    public static final Item POWDERED_CEMENT = registerItem("powdered_cement", new Item(new Item.Settings()));
    public static final Block BAG_OF_CEMENT_BLOCK = registerBlock("bag_of_cement_block", new BagOfCementBlock(AbstractBlock.Settings.copy(Blocks.WHITE_WOOL).strength(0.5f)));
    public static final Item THROWABLE_CEMENT_BAG = registerItem("throwable_cement_bag", new Item(new Item.Settings().maxCount(16)));

    public static final Block WHITE_BRICKS = registerBlock("white_bricks", new Block(AbstractBlock.Settings.copy(Blocks.QUARTZ_BRICKS)));
    public static final Block WHITE_BRICK_STAIRS = registerBlock("white_brick_stairs", new StairsBlock(WHITE_BRICKS.getDefaultState(), AbstractBlock.Settings.copy(WHITE_BRICKS)));
    public static final Block WHITE_BRICK_SLAB = registerBlock("white_brick_slab", new SlabBlock(AbstractBlock.Settings.copy(WHITE_BRICKS)));
    public static final Block WHITE_BRICK_WALL = registerBlock("white_brick_wall", new WallBlock(AbstractBlock.Settings.copy(WHITE_BRICKS)));
    public static final Block GREY_BRICKS = registerBlock("grey_bricks", new Block(AbstractBlock.Settings.copy(Blocks.STONE_BRICKS)));
    public static final Block GREY_BRICK_STAIRS = registerBlock("grey_brick_stairs", new StairsBlock(GREY_BRICKS.getDefaultState(), AbstractBlock.Settings.copy(GREY_BRICKS)));
    public static final Block GREY_BRICK_SLAB = registerBlock("grey_brick_slab", new SlabBlock(AbstractBlock.Settings.copy(GREY_BRICKS)));
    public static final Block GREY_BRICK_WALL = registerBlock("grey_brick_wall", new WallBlock(AbstractBlock.Settings.copy(GREY_BRICKS)));
    public static final Block CONCRETE_BLOCK = registerBlock("concrete_block", new Block(AbstractBlock.Settings.copy(Blocks.LIGHT_GRAY_CONCRETE)));
    public static final Block CONCRETE_POWDER = registerBlock("concrete_powder", new ConcretePowderBlock(CONCRETE_BLOCK, AbstractBlock.Settings.copy(Blocks.LIGHT_GRAY_CONCRETE_POWDER)));

    public static final Item RIPE_CARAMBOLA = registerItem("ripe_carambola", new Item(new Item.Settings().food(new net.minecraft.component.type.FoodComponent.Builder().nutrition(4).saturationModifier(0.3f).build())));
    public static final Item UNRIPE_CARAMBOLA = registerItem("unripe_carambola", new Item(new Item.Settings().food(new net.minecraft.component.type.FoodComponent.Builder().nutrition(1).saturationModifier(0.1f).statusEffect(new StatusEffectInstance(SOURNESS, 100, 0), 1.0f).build())));

    public static final Item TIN_SWORD = registerItem("tin_sword", new SwordItem(ToolMaterials.IRON, new Item.Settings().attributeModifiers(SwordItem.createAttributeModifiers(ToolMaterials.IRON, 4, -2.4f))));
    public static final Item TIN_PICKAXE = registerItem("tin_pickaxe", new PickaxeItem(ToolMaterials.IRON, new Item.Settings()));
    public static final Item TIN_AXE = registerItem("tin_axe", new AxeItem(ToolMaterials.IRON, new Item.Settings()));
    public static final Item TIN_SHOVEL = registerItem("tin_shovel", new ShovelItem(ToolMaterials.IRON, new Item.Settings()));
    public static final Item TIN_HOE = registerItem("tin_hoe", new HoeItem(ToolMaterials.IRON, new Item.Settings()));
    public static final Item MOONCLEAVER = registerItem("mooncleaver", new SwordItem(ToolMaterials.DIAMOND, new Item.Settings().attributeModifiers(SwordItem.createAttributeModifiers(ToolMaterials.DIAMOND, 7, -2.8f))));

    public static final EntityType<ConstructorZombieEntity> CONSTRUCTOR_ZOMBIE = Registry.register(
        Registries.ENTITY_TYPE, id("constructor_zombie"), EntityType.Builder.create(ConstructorZombieEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.95f).maxTrackingRange(8).build("welkin_moon:constructor_zombie"));
    public static final EntityType<GloomStalkerEntity> GLOOM_STALKER = Registry.register(
        Registries.ENTITY_TYPE, id("gloom_stalker"), EntityType.Builder.create(GloomStalkerEntity::new, SpawnGroup.MONSTER).dimensions(0.7f, 2.1f).maxTrackingRange(8).build("welkin_moon:gloom_stalker"));
    public static final EntityType<StrongholdBossEntity> STRONGHOLD_BOSS = Registry.register(
        Registries.ENTITY_TYPE, id("stronghold_boss"), EntityType.Builder.create(StrongholdBossEntity::new, SpawnGroup.MONSTER).dimensions(0.8f, 2.4f).maxTrackingRange(10).build("welkin_moon:stronghold_boss"));

    private static RegistryKey<net.minecraft.world.gen.feature.PlacedFeature> placed(String name) {
        return RegistryKey.of(RegistryKeys.PLACED_FEATURE, id(name));
    }

    @Override public void onInitialize() {
        FabricDefaultAttributeRegistry.register(CONSTRUCTOR_ZOMBIE, ZombieEntity.createZombieAttributes());
        FabricDefaultAttributeRegistry.register(GLOOM_STALKER, ZombieEntity.createZombieAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 32.0).add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 5.0).add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.31));
        FabricDefaultAttributeRegistry.register(STRONGHOLD_BOSS, ZombieEntity.createZombieAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 120.0).add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 12.0)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.30).add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 0.75));

        // Add the new trees to the existing dark/old-growth forest family. This provides a dense, ominous forest feel without replacing vanilla biome data.
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(BiomeKeys.DARK_FOREST), GenerationStep.Feature.VEGETAL_DECORATION, placed("gloomwood_tree"));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(BiomeKeys.DARK_FOREST), GenerationStep.Feature.VEGETAL_DECORATION, placed("carambola_tree"));
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(BiomeKeys.OLD_GROWTH_PINE_TAIGA, BiomeKeys.OLD_GROWTH_SPRUCE_TAIGA), GenerationStep.Feature.VEGETAL_DECORATION, placed("moonwood_tree"));
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Feature.UNDERGROUND_ORES, placed("tin_ore_vein"));
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Feature.UNDERGROUND_ORES, placed("cement_vein"));
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, CONSTRUCTOR_ZOMBIE, 18, 1, 2);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, GLOOM_STALKER, 8, 1, 1);

        // Stronghold encounter: awaken the boss only when a player is near an End Portal Frame in a stronghold portal room.
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (world.getTime() % 40 != 0) return;
            for (ServerPlayerEntity player : world.getPlayers()) {
                BlockPos c = player.getBlockPos();
                boolean portalFrame = false;
                for (int x=-8; x<=8 && !portalFrame; x++) for (int y=-4; y<=4 && !portalFrame; y++) for (int z=-8; z<=8; z++) {
                    if (world.getBlockState(c.add(x,y,z)).isOf(Blocks.END_PORTAL_FRAME)) { portalFrame = true; break; }
                }
                if (portalFrame && world.getEntitiesByClass(StrongholdBossEntity.class, player.getBoundingBox().expand(48), e -> true).isEmpty()) {
                    StrongholdBossEntity boss = STRONGHOLD_BOSS.create(world);
                    if (boss != null) {
                        boss.refreshPositionAndAngles(player.getX()+2.0, player.getY(), player.getZ()+2.0, player.getYaw(), 0);
                        boss.setCustomName(Text.literal("The Hollow King"));
                        boss.setCustomNameVisible(true);
                        boss.setPersistent();
                        world.spawnEntity(boss);
                    }
                }
            }
        });

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.BUILDING_BLOCKS).register(entries -> {
            for (TreeSet t : List.of(BLACKWOOD, GLOOMWOOD, MOONWOOD, CARAMBOLA_TREE)) {
                entries.add(t.log()); entries.add(t.wood()); entries.add(t.strippedLog()); entries.add(t.strippedWood()); entries.add(t.planks()); entries.add(t.leaves());
            }
            entries.add(CORRUGATED_METAL_WALL); entries.add(BAMBOO_PILLAR); entries.add(SOLID_CEMENT); entries.add(SOLID_CEMENT_STAIRS); entries.add(SOLID_CEMENT_SLAB); entries.add(SOLID_CEMENT_WALL); entries.add(CEMENT_BLOCK); entries.add(BAG_OF_CEMENT_BLOCK);
            entries.add(WHITE_BRICKS); entries.add(WHITE_BRICK_STAIRS); entries.add(WHITE_BRICK_SLAB); entries.add(WHITE_BRICK_WALL); entries.add(GREY_BRICKS); entries.add(GREY_BRICK_STAIRS); entries.add(GREY_BRICK_SLAB); entries.add(GREY_BRICK_WALL); entries.add(CONCRETE_BLOCK); entries.add(CONCRETE_POWDER); entries.add(TIN_ORE); entries.add(DEEPSLATE_TIN_ORE); entries.add(METAL_STRING);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> { entries.add(TIN_INGOT); entries.add(TIN_NUGGET); entries.add(BAMBOO_STICK); entries.add(POWDERED_CEMENT); entries.add(THROWABLE_CEMENT_BAG); entries.add(RIPE_CARAMBOLA); entries.add(UNRIPE_CARAMBOLA); });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> { entries.add(TIN_PICKAXE); entries.add(TIN_AXE); entries.add(TIN_SHOVEL); entries.add(TIN_HOE); entries.add(TIN_SWORD); entries.add(MOONCLEAVER); });
    }
}
