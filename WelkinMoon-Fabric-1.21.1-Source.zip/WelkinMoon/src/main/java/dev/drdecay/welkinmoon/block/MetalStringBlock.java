package dev.drdecay.welkinmoon.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.block.ShapeContext;
import net.minecraft.world.World;

import java.util.Map;

public class MetalStringBlock extends Block {
    public static final BooleanProperty HOT = BooleanProperty.of("hot");
    private static final VoxelShape SHAPE = VoxelShapes.cuboid(0.0, 0.43, 0.0, 1.0, 0.57, 1.0);
    private static final Map<Item, Item> COOKING = Map.ofEntries(
        Map.entry(Items.BEEF, Items.COOKED_BEEF), Map.entry(Items.PORKCHOP, Items.COOKED_PORKCHOP),
        Map.entry(Items.CHICKEN, Items.COOKED_CHICKEN), Map.entry(Items.MUTTON, Items.COOKED_MUTTON),
        Map.entry(Items.RABBIT, Items.COOKED_RABBIT), Map.entry(Items.COD, Items.COOKED_COD),
        Map.entry(Items.SALMON, Items.COOKED_SALMON), Map.entry(Items.POTATO, Items.BAKED_POTATO));

    public MetalStringBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(HOT, false));
    }
    @Override protected void appendProperties(StateManager.Builder<Block, BlockState> builder) { builder.add(HOT); }
    @Override protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) { return SHAPE; }
    @Override protected VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) { return SHAPE; }
    @Override protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block sourceBlock, BlockPos sourcePos, boolean notify) {
        if (world.isClient) return;
        boolean powered = world.isReceivingRedstonePower(pos);
        if (powered != state.get(HOT)) world.setBlockState(pos, state.with(HOT, powered));
        if (powered) world.scheduleBlockTick(pos, this, 30);
    }
    @Override protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
        if (!world.isClient && world.isReceivingRedstonePower(pos)) world.scheduleBlockTick(pos, this, 30);
    }
    @Override protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (!world.isReceivingRedstonePower(pos)) {
            world.setBlockState(pos, state.with(HOT, false));
            return;
        }
        if (!state.get(HOT)) world.setBlockState(pos, state.with(HOT, true));
        Box box = new Box(pos).expand(0.28);
        for (Entity entity : world.getOtherEntities(null, box)) {
            if (entity instanceof LivingEntity living) {
                living.setOnFireFor(2);
                living.damage(world.getDamageSources().inFire(), 1.0f);
            }
        }
        // Nearby ice melts from the sustained heat.
        for (Direction d : Direction.values()) {
            BlockPos p = pos.offset(d);
            Block b = world.getBlockState(p).getBlock();
            if (b == Blocks.ICE || b == Blocks.PACKED_ICE || b == Blocks.BLUE_ICE) world.setBlockState(p, Blocks.WATER.getDefaultState());
        }
        // Food dropped directly on the string cooks over a few heating cycles.
        Box foodBox = new Box(pos.getX(), pos.getY()+0.5, pos.getZ(), pos.getX()+1, pos.getY()+1.25, pos.getZ()+1);
        for (ItemEntity itemEntity : world.getEntitiesByClass(ItemEntity.class, foodBox, e -> true)) {
            Item cooked = COOKING.get(itemEntity.getStack().getItem());
            if (cooked != null && world.random.nextInt(4) == 0) itemEntity.setStack(new ItemStack(cooked, itemEntity.getStack().getCount()));
        }
        world.scheduleBlockTick(pos, this, 20);
    }
    @Override protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
        if (!world.isClient && state.get(HOT) && entity instanceof LivingEntity living) {
            living.setOnFireFor(2);
            living.damage(world.getDamageSources().inFire(), 1.0f);
        }
    }
}
