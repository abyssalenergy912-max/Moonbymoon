package dev.drdecay.welkinmoon.entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.world.World;
public class GloomStalkerEntity extends ZombieEntity {
    public GloomStalkerEntity(EntityType<? extends ZombieEntity> type, World world) { super(type, world); }
}
