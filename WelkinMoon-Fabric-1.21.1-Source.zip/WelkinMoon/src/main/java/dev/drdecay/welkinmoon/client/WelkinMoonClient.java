package dev.drdecay.welkinmoon.client;

import dev.drdecay.welkinmoon.WelkinMoon;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.ZombieEntityModel;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;

public final class WelkinMoonClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        EntityRendererRegistry.register(WelkinMoon.CONSTRUCTOR_ZOMBIE, ctx -> new SimpleZombieRenderer<>(ctx, Identifier.ofVanilla("textures/entity/zombie/zombie.png")));
        EntityRendererRegistry.register(WelkinMoon.GLOOM_STALKER, ctx -> new SimpleZombieRenderer<>(ctx, Identifier.ofVanilla("textures/entity/zombie/husk.png")));
        EntityRendererRegistry.register(WelkinMoon.STRONGHOLD_BOSS, ctx -> new SimpleZombieRenderer<>(ctx, Identifier.ofVanilla("textures/entity/zombie/zombie.png")));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player != null && client.world != null && client.player.hasStatusEffect(WelkinMoon.SOURNESS)) {
                client.player.setYaw(client.player.getYaw() + (client.world.random.nextFloat() - 0.5f) * 1.4f);
                client.player.setPitch(Math.max(-89.0f, Math.min(89.0f, client.player.getPitch() + (client.world.random.nextFloat() - 0.5f) * 1.0f)));
            }
        });
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player != null && client.player.hasStatusEffect(WelkinMoon.SOURNESS)) {
                int w = client.getWindow().getScaledWidth(), h = client.getWindow().getScaledHeight();
                drawContext.fill(0, 0, w, h, 0x160D2F08);
                drawContext.fill(0, 0, w, 2, 0x303D5E17);
            }
        });
    }

    private static final class SimpleZombieRenderer<T extends ZombieEntity> extends MobEntityRenderer<T, ZombieEntityModel<T>> {
        private final Identifier texture;
        SimpleZombieRenderer(EntityRendererFactory.Context context, Identifier texture) {
            super(context, new ZombieEntityModel<>(context.getPart(EntityModelLayers.ZOMBIE)), 0.5f);
            this.texture = texture;
        }
        @Override public Identifier getTexture(T entity) { return texture; }
    }
}
