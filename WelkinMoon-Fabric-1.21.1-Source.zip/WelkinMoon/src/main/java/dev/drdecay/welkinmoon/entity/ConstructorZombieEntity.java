package dev.drdecay.welkinmoon.entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.world.World;
public class ConstructorZombieEntity extends ZombieEntity {
    public ConstructorZombieEntity(EntityType<? extends ZombieEntity> type, World world) { super(type, world); }
}
