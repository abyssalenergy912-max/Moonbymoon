# Welkin Moon — Fabric 1.21.1
**Author:** Dr.Decay  
**Minecraft:** Java Edition 1.21.1  
**Loader:** Fabric  
**Java:** 21

## Build the mod JAR
This folder is a Gradle/Fabric source project. A compiled JAR could not be produced in the current offline build environment, so a GitHub Actions workflow is included to compile it automatically:

1. Create a repository on GitHub and upload the contents of this folder (not the outer ZIP).
2. Open **Actions** → **Build Welkin Moon** → **Run workflow**.
3. If the build succeeds, open the workflow run and download the **welkin-moon-jar** artifact. The actual mod JAR is inside that artifact.

You can also build locally with Java 21 and Gradle 8.8 using `gradle build`. The resulting JAR is under `build/libs/`.

## Current implementation notes
This is a large-content first pass. Included: registered woods/logs/leaves/planks, carambola fruit and Sourness effect (screen tint + camera wobble (not a true blur shader)), tin ore and tin tools, concrete/cement building blocks and variants, the redstone-heated Metal String behavior, custom hostile zombie variants, a stronghold-portal boss trigger, added tree/ore world-generation features, simple recipes, translations, models, loot tables, and data-driven enchantment definitions.

Some high-complexity parts are intentionally starter implementations rather than polished content: the forest content is added to existing dark/old-growth forest biomes instead of introducing a fully selectable biome; the **Unfinished Project** structure template is not implemented yet (Constructor Zombie is currently added to general Overworld monster spawning); the `throwable_cement_bag` item is registered, but its projectile throw, impact damage, and grey-smoke effect are not implemented yet. The custom enchantment data files are included, but only Moon Surge currently has a gameplay effect; Deep Vein and Woodland Echo are placeholders. Please test a new world first and back up existing worlds.


**Build status:** The project source and resources were statically checked, but Minecraft/Fabric dependencies could not be downloaded in this environment, so no successful compilation is claimed. Treat it as an initial development build and inspect the GitHub Actions build result before installing.
